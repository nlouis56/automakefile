int	toto(void)
{
  return (0);
}
